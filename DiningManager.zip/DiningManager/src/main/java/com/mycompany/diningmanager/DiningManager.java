/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diningmanager;

/**
 *
 * @author CltControl
 */
public class DiningManager {

    public static void main(String[] args) {
        System.out.println("Dining Experience Manager");
        
    }
}
