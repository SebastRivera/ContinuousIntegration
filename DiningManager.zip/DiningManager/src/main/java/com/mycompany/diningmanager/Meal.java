/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.diningmanager;

/**
 *
 * @author CltControl
 */
public class Meal {
    private String name;
    private float price = 5;
    private int quantity;
    private boolean chefSpecial;
    private boolean availability;

    public boolean getAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public boolean isChefSpecial() {
        return chefSpecial;
    }

    public void setChefSpecial(boolean chefSpecial) {
        this.chefSpecial = chefSpecial;
    }
        
    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public float getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    
    public boolean validateQuantity(int quantity){
        return quantity > 0;
    }
}
